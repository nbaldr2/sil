import React, { useState, createContext, useContext, useEffect } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import LoginPage from './components/LoginPage';
import Dashboard from './components/Dashboard';
import RequestManagement from './components/RequestManagement';
import PatientManagement from './components/PatientManagement';
import DoctorManagement from './components/DoctorManagement';
import PriceManagement from './components/PriceManagement';
import ResultEntryPage from './components/ResultEntryPage';
import BillingModule from './components/BillingModule';
import PrintingModule from './components/PrintingModule';
import ImportExport from './components/ImportExport';
import ConfigCenter from './components/ConfigCenter';
import UserManagement from './components/UserManagement';
import NewAnalysisRequest from './components/NewAnalysisRequest';
import AnalysisValidation from './components/AnalysisValidation';
import BiologistDashboard from './components/BiologistDashboard';
import RoleBasedAccess from './components/RoleBasedAccess';
import Header from './components/Header';
import Sidebar from './components/Sidebar';

interface User {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'biologist' | 'technician' | 'secretary';
}

interface AuthContextType {
  user: User | null;
  login: (email: string, password: string) => boolean;
  logout: () => void;
  language: 'fr' | 'en';
  setLanguage: (lang: 'fr' | 'en') => void;
  theme: 'light' | 'dark';
  toggleTheme: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [language, setLanguage] = useState<'fr' | 'en'>('fr');
  const [theme, setTheme] = useState<'light' | 'dark'>(() => {
    // Initialize theme from localStorage or system preference or default to 'light'
    const savedTheme = localStorage.getItem('theme') as 'light' | 'dark';
    if (savedTheme) {
      return savedTheme;
    }
    // Check system preference
    if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
      return 'dark';
    }
    return 'light';
  });

  const login = (email: string, password: string): boolean => {
    if (email === 'admin@lab.fr' && password === 'admin') {
      setUser({ id: '1', name: 'Dr. Admin', email, role: 'admin' });
      return true;
    }
    if (email === 'bio@lab.fr' && password === '123456') {
      setUser({ id: '2', name: 'Dr. Biologist', email, role: 'biologist' });
      return true;
    }
    if (email === 'secretary@lab.fr' && password === '123456') {
      setUser({ id: '3', name: 'Nadia Secretary', email, role: 'secretary' });
      return true;
    }
    return false;
  };

  const logout = () => {
    setUser(null);
  };

  const toggleTheme = () => {
    setTheme(prev => {
      const newTheme = prev === 'light' ? 'dark' : 'light';
      localStorage.setItem('theme', newTheme);
      return newTheme;
    });
  };

  // Listen for system theme changes
  React.useEffect(() => {
    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
    const handleChange = (e: MediaQueryListEvent) => {
      // Only update if no manual theme is saved
      if (!localStorage.getItem('theme')) {
        setTheme(e.matches ? 'dark' : 'light');
      }
    };
    mediaQuery.addEventListener('change', handleChange);
    return () => mediaQuery.removeEventListener('change', handleChange);
  }, []);

  // Apply theme to document
  useEffect(() => {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [theme]);

  const authValue: AuthContextType = {
    user,
    login,
    logout,
    language,
    setLanguage,
    theme,
    toggleTheme
  };

  return (
    <AuthContext.Provider value={authValue}>
      {!user ? (
        <LoginPage />
      ) : (
        <div className="flex h-screen bg-gray-100 dark:bg-gray-900">
          <Sidebar />
          <div className="flex-1 flex flex-col overflow-hidden">
            <Header />
            <main className="flex-1 overflow-x-hidden overflow-y-auto bg-gray-100 dark:bg-gray-900">
              <Routes>
                <Route path="/" element={<Dashboard />} />
                <Route path="/requests" element={<RequestManagement />} />
                <Route path="/patients" element={<PatientManagement />} />
                <Route path="/doctors" element={<DoctorManagement />} />
                <Route path="/pricing" element={<PriceManagement />} />
                <Route path="/new-request" element={<NewAnalysisRequest />} />
                <Route path="/results" element={<ResultEntryPage />} />
                <Route path="/validation" element={<AnalysisValidation />} />
                <Route path="/billing" element={<BillingModule />} />
                <Route path="/printing" element={<PrintingModule />} />
                <Route path="/import-export" element={<ImportExport />} />
                <Route path="/config" element={<ConfigCenter />} />
                <Route path="/users" element={<UserManagement />} />
                <Route path="/biologist" element={<BiologistDashboard />} />
                <Route path="*" element={<Navigate to="/" replace />} />
              </Routes>
            </main>
          </div>
        </div>
      )}
    </AuthContext.Provider>
  );
}
 