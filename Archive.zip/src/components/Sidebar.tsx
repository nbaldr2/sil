import React from 'react';
import { NavLink } from 'react-router-dom';
import { Home, Database, Users, FileText, CreditCard, Printer, Upload, Settings, User, Plus, DollarSign, Stethoscope } from 'lucide-react';
import { useAuth } from '../App';

export default function Sidebar() {
  const { language, user } = useAuth();

  const getNavItems = () => {
    const baseItems = [
      { path: '/', label: language === 'fr' ? 'Tableau de Bord' : 'Dashboard', icon: Home, roles: ['admin', 'biologist', 'technician', 'secretary'] }
    ];

    // Add new request prominently for receptionists
    if (user?.role === 'secretary' || user?.role === 'admin') {
      baseItems.push({
        path: '/new-request',
        label: language === 'fr' ? 'Nouvelle Demande' : 'New Request',
        icon: Plus,
        roles: ['secretary', 'admin']
      });
    }

    // Add other items based on role
    if (user?.role === 'admin') {
      return [
        ...baseItems,
        { path: '/requests', label: language === 'fr' ? 'Gestion Demandes' : 'Request Management', icon: Database, roles: ['admin'] },
        { path: '/patients', label: language === 'fr' ? 'Gestion Patients' : 'Patient Management', icon: Users, roles: ['admin'] },
        { path: '/doctors', label: language === 'fr' ? 'Gestion Médecins' : 'Doctor Management', icon: Stethoscope, roles: ['admin'] },
        { path: '/pricing', label: language === 'fr' ? 'Gestion Prix' : 'Price Management', icon: DollarSign, roles: ['admin'] },
        { path: '/results', label: language === 'fr' ? 'Résultats' : 'Results', icon: FileText, roles: ['admin'] },
        { path: '/billing', label: language === 'fr' ? 'Facturation' : 'Billing', icon: CreditCard, roles: ['admin'] },
        { path: '/printing', label: language === 'fr' ? 'Impression' : 'Printing', icon: Printer, roles: ['admin'] },
        { path: '/import-export', label: language === 'fr' ? 'Import/Export' : 'Import/Export', icon: Upload, roles: ['admin'] },
        { path: '/config', label: language === 'fr' ? 'Configuration' : 'Configuration', icon: Settings, roles: ['admin'] },
        { path: '/users', label: language === 'fr' ? 'Utilisateurs' : 'Users', icon: User, roles: ['admin'] }
      ];
    }

    if (user?.role === 'secretary') {
      return [
        ...baseItems,
        { path: '/requests', label: language === 'fr' ? 'Demandes' : 'Requests', icon: Database, roles: ['secretary'] },
        { path: '/patients', label: language === 'fr' ? 'Patients' : 'Patients', icon: Users, roles: ['secretary'] },
        { path: '/doctors', label: language === 'fr' ? 'Médecins' : 'Doctors', icon: Stethoscope, roles: ['secretary'] },
        { path: '/billing', label: language === 'fr' ? 'Facturation' : 'Billing', icon: CreditCard, roles: ['secretary'] }
      ];
    }

    if (user?.role === 'biologist') {
      return [
        ...baseItems,
        { path: '/validation', label: language === 'fr' ? 'Validation' : 'Validation', icon: FileText, roles: ['biologist'] },
        { path: '/results', label: language === 'fr' ? 'Résultats' : 'Results', icon: FileText, roles: ['biologist'] },
        { path: '/patients', label: language === 'fr' ? 'Patients' : 'Patients', icon: Users, roles: ['biologist'] },
        { path: '/printing', label: language === 'fr' ? 'Impression' : 'Printing', icon: Printer, roles: ['biologist'] }
      ];
    }

    if (user?.role === 'technician') {
      return [
        ...baseItems,
        { path: '/results', label: language === 'fr' ? 'Saisie Résultats' : 'Result Entry', icon: FileText, roles: ['technician'] },
        { path: '/printing', label: language === 'fr' ? 'Impression' : 'Printing', icon: Printer, roles: ['technician'] }
      ];
    }

    return baseItems;
  };

  const navItems = getNavItems();

  return (
    <div className="w-64 bg-gray-900 text-white h-full">
      <div className="p-4">
        <h2 className="text-xl font-bold mb-6">SIL Lab</h2>
        <nav className="space-y-2">
          {navItems.filter(item => item.roles.includes(user?.role || '')).map((item) => (
            <NavLink
              key={item.path}
              to={item.path}
              className={({ isActive }) =>
                `flex items-center space-x-3 px-3 py-2 rounded-lg transition-colors ${
                  isActive
                    ? 'bg-blue-600 text-white'
                    : 'text-gray-300 hover:bg-gray-800 hover:text-white'
                }`
              }
            >
              <item.icon size={20} />
              <span>{item.label}</span>
            </NavLink>
          ))}
        </nav>
      </div>
    </div>
  );
}
 