import React, { useState, useEffect } from 'react';
import { 
  Users, 
  FileText, 
  DollarSign, 
  TrendingUp, 
  TrendingDown, 
  Clock, 
  AlertTriangle, 
  CheckCircle, 
  Calendar,
  BarChart3,
  PieChart,
  Activity,
  Target,
  Award,
  Zap,
  Eye,
  Heart,
  Stethoscope,
  TestTube,
  Microscope
} from 'lucide-react';
import { useAuth } from '../App';
import { sheetsService, pricingService } from '../services/integrations';

interface DashboardData {
  totalRequests: number;
  pendingRequests: number;
  completedRequests: number;
  urgentRequests: number;
  totalRevenue: number;
  averageRevenue: number;
  totalPatients: number;
  totalDoctors: number;
  monthlyGrowth: number;
  topAnalyses: Array<{ name: string; count: number; revenue: number }>;
  recentRequests: Array<any>;
  revenueByMonth: Array<{ month: string; revenue: number }>;
  statusDistribution: Array<{ status: string; count: number; percentage: number }>;
}

export default function Dashboard() {
  const { language, user } = useAuth();
  const [dashboardData, setDashboardData] = useState<DashboardData>({
    totalRequests: 0,
    pendingRequests: 0,
    completedRequests: 0,
    urgentRequests: 0,
    totalRevenue: 0,
    averageRevenue: 0,
    totalPatients: 0,
    totalDoctors: 0,
    monthlyGrowth: 0,
    topAnalyses: [],
    recentRequests: [],
    revenueByMonth: [],
    statusDistribution: []
  });
  const [isLoading, setIsLoading] = useState(true);
  const [selectedPeriod, setSelectedPeriod] = useState('month');

  const t = {
    fr: {
      title: 'Tableau de Bord',
      subtitle: 'Vue d\'ensemble du laboratoire',
      totalRequests: 'Total Demandes',
      pendingRequests: 'Demandes en Attente',
      completedRequests: 'Demandes Terminées',
      urgentRequests: 'Demandes Urgentes',
      totalRevenue: 'Revenu Total',
      averageRevenue: 'Revenu Moyen',
      totalPatients: 'Total Patients',
      totalDoctors: 'Total Médecins',
      monthlyGrowth: 'Croissance Mensuelle',
      topAnalyses: 'Analyses les Plus Demandées',
      recentRequests: 'Demandes Récentes',
      revenueByMonth: 'Revenus par Mois',
      statusDistribution: 'Répartition par Statut',
      period: 'Période',
      today: 'Aujourd\'hui',
      week: 'Cette Semaine',
      month: 'Ce Mois',
      quarter: 'Ce Trimestre',
      year: 'Cette Année',
      patient: 'Patient',
      doctor: 'Médecin',
      analyses: 'Analyses',
      status: 'Statut',
      date: 'Date',
      amount: 'Montant',
      urgent: 'Urgent',
      normal: 'Normal',
      pending: 'En attente',
      completed: 'Terminé',
      processing: 'En cours',
      cancelled: 'Annulé',
      noData: 'Aucune donnée disponible',
      loading: 'Chargement...',
      viewAll: 'Voir tout',
      performance: 'Performance',
      efficiency: 'Efficacité',
      quality: 'Qualité',
      productivity: 'Productivité',
      turnaroundTime: 'Délai de Traitement',
      averageTime: 'Temps Moyen',
      hours: 'heures',
      accuracy: 'Précision',
      percentage: '%',
      satisfaction: 'Satisfaction Client',
      rating: 'Note',
      outOf: 'sur 5',
      newPatients: 'Nouveaux Patients',
      returningPatients: 'Patients Fidèles',
      doctorReferrals: 'Références Médecins',
      topDoctors: 'Médecins les Plus Actifs',
      revenueTrend: 'Tendance des Revenus',
      requestTrend: 'Tendance des Demandes',
      efficiencyMetrics: 'Métriques d\'Efficacité',
      qualityMetrics: 'Métriques de Qualité',
      financialMetrics: 'Métriques Financières',
      operationalMetrics: 'Métriques Opérationnelles'
    },
    en: {
      title: 'Dashboard',
      subtitle: 'Laboratory overview',
      totalRequests: 'Total Requests',
      pendingRequests: 'Pending Requests',
      completedRequests: 'Completed Requests',
      urgentRequests: 'Urgent Requests',
      totalRevenue: 'Total Revenue',
      averageRevenue: 'Average Revenue',
      totalPatients: 'Total Patients',
      totalDoctors: 'Total Doctors',
      monthlyGrowth: 'Monthly Growth',
      topAnalyses: 'Most Requested Analyses',
      recentRequests: 'Recent Requests',
      revenueByMonth: 'Revenue by Month',
      statusDistribution: 'Status Distribution',
      period: 'Period',
      today: 'Today',
      week: 'This Week',
      month: 'This Month',
      quarter: 'This Quarter',
      year: 'This Year',
      patient: 'Patient',
      doctor: 'Doctor',
      analyses: 'Analyses',
      status: 'Status',
      date: 'Date',
      amount: 'Amount',
      urgent: 'Urgent',
      normal: 'Normal',
      pending: 'Pending',
      completed: 'Completed',
      processing: 'Processing',
      cancelled: 'Cancelled',
      noData: 'No data available',
      loading: 'Loading...',
      viewAll: 'View all',
      performance: 'Performance',
      efficiency: 'Efficiency',
      quality: 'Quality',
      productivity: 'Productivity',
      turnaroundTime: 'Turnaround Time',
      averageTime: 'Average Time',
      hours: 'hours',
      accuracy: 'Accuracy',
      percentage: '%',
      satisfaction: 'Customer Satisfaction',
      rating: 'Rating',
      outOf: 'out of 5',
      newPatients: 'New Patients',
      returningPatients: 'Returning Patients',
      doctorReferrals: 'Doctor Referrals',
      topDoctors: 'Most Active Doctors',
      revenueTrend: 'Revenue Trend',
      requestTrend: 'Request Trend',
      efficiencyMetrics: 'Efficiency Metrics',
      qualityMetrics: 'Quality Metrics',
      financialMetrics: 'Financial Metrics',
      operationalMetrics: 'Operational Metrics'
    }
  }[language];

  useEffect(() => {
    loadDashboardData();
  }, [selectedPeriod]);

  const loadDashboardData = async () => {
    setIsLoading(true);
    try {
      // Load requests data
      const requestsResult = await sheetsService.getRequests();
      const requests = requestsResult.success ? requestsResult.data : [];
      
      // Load prices data
      const prices = pricingService.getPrices();
      
      // Calculate dashboard metrics
      const totalRequests = requests.length;
      const pendingRequests = requests.filter((r: any) => r.status === 'pending' || r.status === 'processing').length;
      const completedRequests = requests.filter((r: any) => r.status === 'completed').length;
      const urgentRequests = requests.filter((r: any) => r.urgent).length;
      
      // Calculate revenue
      let totalRevenue = 0;
      const analysisCounts: { [key: string]: number } = {};
      
      requests.forEach((request: any) => {
        if (request.analyses) {
          request.analyses.forEach((analysis: any) => {
            const priceInfo = prices.find((p: any) => p.code === analysis.code);
            if (priceInfo) {
              const price = priceInfo.price * (1 + priceInfo.tva / 100);
              totalRevenue += price;
            }
            
            analysisCounts[analysis.nom] = (analysisCounts[analysis.nom] || 0) + 1;
          });
        }
      });
      
      const averageRevenue = totalRequests > 0 ? totalRevenue / totalRequests : 0;
      
      // Get unique patients and doctors
      const uniquePatients = new Set(requests.map((r: any) => r.patient?.numeroCNSS)).size;
      const uniqueDoctors = new Set(requests.map((r: any) => r.doctor?.id)).size;
      
      // Calculate monthly growth (simplified)
      const currentMonth = new Date().getMonth();
      const lastMonth = new Date();
      lastMonth.setMonth(currentMonth - 1);
      
      const currentMonthRequests = requests.filter((r: any) => {
        const requestDate = new Date(r.createdAt);
        return requestDate.getMonth() === currentMonth;
      }).length;
      
      const lastMonthRequests = requests.filter((r: any) => {
        const requestDate = new Date(r.createdAt);
        return requestDate.getMonth() === lastMonth.getMonth();
      }).length;
      
      const monthlyGrowth = lastMonthRequests > 0 ? ((currentMonthRequests - lastMonthRequests) / lastMonthRequests) * 100 : 0;
      
      // Top analyses
      const topAnalyses = Object.entries(analysisCounts)
        .map(([name, count]) => {
          const priceInfo = prices.find((p: any) => p.nom === name);
          const revenue = priceInfo ? count * priceInfo.price * (1 + priceInfo.tva / 100) : 0;
          return { name, count, revenue };
        })
        .sort((a, b) => b.count - a.count)
        .slice(0, 5);
      
      // Recent requests
      const recentRequests = requests
        .sort((a: any, b: any) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
        .slice(0, 5);
      
      // Revenue by month (last 6 months)
      const revenueByMonth = [];
      for (let i = 5; i >= 0; i--) {
        const date = new Date();
        date.setMonth(date.getMonth() - i);
        const monthName = date.toLocaleDateString(language === 'fr' ? 'fr-FR' : 'en-US', { month: 'short' });
        
        const monthRequests = requests.filter((r: any) => {
          const requestDate = new Date(r.createdAt);
          return requestDate.getMonth() === date.getMonth() && requestDate.getFullYear() === date.getFullYear();
        });
        
        let monthRevenue = 0;
        monthRequests.forEach((request: any) => {
          if (request.analyses) {
            request.analyses.forEach((analysis: any) => {
              const priceInfo = prices.find((p: any) => p.code === analysis.code);
              if (priceInfo) {
                monthRevenue += priceInfo.price * (1 + priceInfo.tva / 100);
              }
            });
          }
        });
        
        revenueByMonth.push({ month: monthName, revenue: monthRevenue });
      }
      
      // Status distribution
      const statusCounts: { [key: string]: number } = {};
      requests.forEach((r: any) => {
        const status = r.status || 'pending';
        statusCounts[status] = (statusCounts[status] || 0) + 1;
      });
      
      const statusDistribution = Object.entries(statusCounts).map(([status, count]) => ({
        status,
        count,
        percentage: (count / totalRequests) * 100
      }));
      
      setDashboardData({
        totalRequests,
        pendingRequests,
        completedRequests,
        urgentRequests,
        totalRevenue,
        averageRevenue,
        totalPatients: uniquePatients,
        totalDoctors: uniqueDoctors,
        monthlyGrowth,
        topAnalyses,
        recentRequests,
        revenueByMonth,
        statusDistribution
      });
    } catch (error) {
      console.error('Error loading dashboard data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'text-green-600 bg-green-100 dark:bg-green-900/20 dark:text-green-400';
      case 'processing': return 'text-blue-600 bg-blue-100 dark:bg-blue-900/20 dark:text-blue-400';
      case 'pending': return 'text-yellow-600 bg-yellow-100 dark:bg-yellow-900/20 dark:text-yellow-400';
      case 'cancelled': return 'text-red-600 bg-red-100 dark:bg-red-900/20 dark:text-red-400';
      default: return 'text-gray-600 bg-gray-100 dark:bg-gray-900/20 dark:text-gray-400';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'completed': return t.completed;
      case 'processing': return t.processing;
      case 'pending': return t.pending;
      case 'cancelled': return t.cancelled;
      default: return t.pending;
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto p-6">
      <div className="mb-8">
        <h2 className="text-3xl font-bold text-gray-900 dark:text-white">{t.title}</h2>
        <p className="text-gray-600 dark:text-gray-400 mt-2">{t.subtitle}</p>
      </div>

      {/* Period Selector */}
      <div className="mb-6">
        <div className="flex space-x-2">
          {['today', 'week', 'month', 'quarter', 'year'].map((period) => (
            <button
              key={period}
              onClick={() => setSelectedPeriod(period)}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                selectedPeriod === period
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600'
              }`}
            >
              {t[period as keyof typeof t]}
            </button>
          ))}
        </div>
      </div>

      {/* Main KPIs */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
          <div className="flex items-center">
            <FileText className="h-8 w-8 text-blue-600 mr-3" />
            <div>
              <p className="text-sm text-gray-600 dark:text-gray-400">{t.totalRequests}</p>
              <p className="text-2xl font-bold text-gray-900 dark:text-white">{dashboardData.totalRequests}</p>
            </div>
          </div>
          <div className="mt-2 flex items-center text-sm">
            {dashboardData.monthlyGrowth > 0 ? (
              <TrendingUp className="h-4 w-4 text-green-600 mr-1" />
            ) : (
              <TrendingDown className="h-4 w-4 text-red-600 mr-1" />
            )}
            <span className={dashboardData.monthlyGrowth > 0 ? 'text-green-600' : 'text-red-600'}>
              {Math.abs(dashboardData.monthlyGrowth).toFixed(1)}%
            </span>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
          <div className="flex items-center">
            <DollarSign className="h-8 w-8 text-green-600 mr-3" />
            <div>
              <p className="text-sm text-gray-600 dark:text-gray-400">{t.totalRevenue}</p>
              <p className="text-2xl font-bold text-gray-900 dark:text-white">
                {dashboardData.totalRevenue.toFixed(2)} dh
              </p>
            </div>
          </div>
          <div className="mt-2 text-sm text-gray-600 dark:text-gray-400">
            {t.averageRevenue}: {(dashboardData.averageRevenue).toFixed(2)} dh
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
          <div className="flex items-center">
            <Users className="h-8 w-8 text-purple-600 mr-3" />
            <div>
              <p className="text-sm text-gray-600 dark:text-gray-400">{t.totalPatients}</p>
              <p className="text-2xl font-bold text-gray-900 dark:text-white">{dashboardData.totalPatients}</p>
            </div>
          </div>
          <div className="mt-2 text-sm text-gray-600 dark:text-gray-400">
            {t.totalDoctors}: {dashboardData.totalDoctors}
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
          <div className="flex items-center">
            <AlertTriangle className="h-8 w-8 text-orange-600 mr-3" />
            <div>
              <p className="text-sm text-gray-600 dark:text-gray-400">{t.urgentRequests}</p>
              <p className="text-2xl font-bold text-gray-900 dark:text-white">{dashboardData.urgentRequests}</p>
            </div>
          </div>
          <div className="mt-2 text-sm text-gray-600 dark:text-gray-400">
            {t.pendingRequests}: {dashboardData.pendingRequests}
          </div>
        </div>
      </div>

      {/* Secondary Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
          <div className="flex items-center mb-4">
            <Activity className="h-6 w-6 text-blue-600 mr-2" />
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white">{t.efficiencyMetrics}</h3>
          </div>
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-gray-600 dark:text-gray-400">{t.turnaroundTime}:</span>
              <span className="font-medium">24 {t.hours}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600 dark:text-gray-400">{t.accuracy}:</span>
              <span className="font-medium text-green-600">99.8{t.percentage}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600 dark:text-gray-400">{t.satisfaction}:</span>
              <span className="font-medium">4.8 {t.outOf}</span>
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
          <div className="flex items-center mb-4">
            <Target className="h-6 w-6 text-green-600 mr-2" />
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white">{t.qualityMetrics}</h3>
          </div>
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-gray-600 dark:text-gray-400">{t.completedRequests}:</span>
              <span className="font-medium text-green-600">{dashboardData.completedRequests}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600 dark:text-gray-400">{t.processing}:</span>
              <span className="font-medium text-blue-600">{dashboardData.pendingRequests}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600 dark:text-gray-400">{t.urgentRequests}:</span>
              <span className="font-medium text-orange-600">{dashboardData.urgentRequests}</span>
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
          <div className="flex items-center mb-4">
            <Award className="h-6 w-6 text-purple-600 mr-2" />
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white">{t.performance}</h3>
          </div>
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-gray-600 dark:text-gray-400">{t.newPatients}:</span>
              <span className="font-medium">{Math.floor(dashboardData.totalPatients * 0.3)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600 dark:text-gray-400">{t.returningPatients}:</span>
              <span className="font-medium">{Math.floor(dashboardData.totalPatients * 0.7)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600 dark:text-gray-400">{t.doctorReferrals}:</span>
              <span className="font-medium">{dashboardData.totalDoctors}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Charts and Tables */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        {/* Top Analyses */}
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white">{t.topAnalyses}</h3>
            <BarChart3 className="h-5 w-5 text-gray-400" />
          </div>
          <div className="space-y-3">
            {dashboardData.topAnalyses.length > 0 ? (
              dashboardData.topAnalyses.map((analysis, index) => (
                <div key={analysis.name} className="flex items-center justify-between">
                  <div className="flex items-center">
                    <div className="w-8 h-8 bg-blue-100 dark:bg-blue-900/20 rounded-full flex items-center justify-center mr-3">
                      <span className="text-sm font-medium text-blue-600 dark:text-blue-400">{index + 1}</span>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-gray-900 dark:text-white">{analysis.name}</p>
                      <p className="text-xs text-gray-600 dark:text-gray-400">{analysis.count} {t.analyses}</p>
                    </div>
                  </div>
                  <span className="text-sm font-medium text-green-600">{analysis.revenue.toFixed(2)} dh</span>
                </div>
              ))
            ) : (
              <p className="text-gray-500 dark:text-gray-400 text-center py-4">{t.noData}</p>
            )}
          </div>
        </div>

        {/* Status Distribution */}
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white">{t.statusDistribution}</h3>
            <PieChart className="h-5 w-5 text-gray-400" />
          </div>
          <div className="space-y-3">
            {dashboardData.statusDistribution.length > 0 ? (
              dashboardData.statusDistribution.map((item) => (
                <div key={item.status} className="flex items-center justify-between">
                  <div className="flex items-center">
                    <div className="w-3 h-3 rounded-full mr-3 bg-blue-500"></div>
                    <span className="text-sm text-gray-900 dark:text-white">{getStatusText(item.status)}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="text-sm font-medium text-gray-900 dark:text-white">{item.count}</span>
                    <span className="text-xs text-gray-600 dark:text-gray-400">({item.percentage.toFixed(1)}%)</span>
                  </div>
                </div>
              ))
            ) : (
              <p className="text-gray-500 dark:text-gray-400 text-center py-4">{t.noData}</p>
            )}
          </div>
        </div>
      </div>

      {/* Recent Requests */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white">{t.recentRequests}</h3>
          <button className="text-blue-600 hover:text-blue-700 text-sm font-medium">
            {t.viewAll}
          </button>
        </div>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
            <thead className="bg-gray-50 dark:bg-gray-700">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  {t.patient}
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  {t.doctor}
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  {t.analyses}
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  {t.status}
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  {t.date}
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  {t.amount}
                </th>
              </tr>
            </thead>
            <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
              {dashboardData.recentRequests.length > 0 ? (
                dashboardData.recentRequests.map((request: any) => (
                  <tr key={request.id} className="hover:bg-gray-50 dark:hover:bg-gray-700">
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">
                      {request.patient?.prenom} {request.patient?.nom}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">
                      Dr. {request.doctor?.prenom} {request.doctor?.nom}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600 dark:text-gray-400">
                      {request.analyses?.length || 0} {t.analyses}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(request.status)}`}>
                        {getStatusText(request.status)}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600 dark:text-gray-400">
                      {new Date(request.createdAt).toLocaleDateString()}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-green-600">
                      {request.pricing?.amountDue?.toFixed(2) || '0.00'} dh
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={6} className="px-6 py-8 text-center text-gray-500 dark:text-gray-400">
                    {t.noData}
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
 