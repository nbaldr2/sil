import  React, { useState, useEffect } from 'react';
import { Search, Plus, Eye, Edit, X, Filter } from 'lucide-react';
import { useAuth } from '../App';
import { sheetsService } from '../services/integrations';

interface Request {
  id: string;
  patientName: string;
  tests: string[];
  status: 'created' | 'collected' | 'analysis' | 'validated';
  priority: 'normal' | 'urgent';
  createdAt: string;
}

export default function RequestManagement() {
  const { language } = useAuth();
  const [searchTerm, setSearchTerm] = useState('');
  const [showNewModal, setShowNewModal] = useState(false);
  const [showViewModal, setShowViewModal] = useState(false);
  const [selectedRequest, setSelectedRequest] = useState<Request | null>(null);
  const [showFilter, setShowFilter] = useState(false);
  const [requests, setRequests] = useState<Request[]>([]);
  const [loading, setLoading] = useState(true);

  const t = {
    fr: {
      title: 'Gestion des Demandes',
      newRequest: 'Nouvelle Demande',
      search: 'Rechercher...',
      id: 'ID',
      patient: 'Patient',
      tests: 'Analyses',
      status: 'Statut',
      priority: 'Priorité',
      date: 'Date',
      actions: 'Actions',
      close: 'Fermer',
      save: 'Enregistrer',
      cancel: 'Annuler'
    },
    en: {
      title: 'Request Management',
      newRequest: 'New Request',
      search: 'Search...',
      id: 'ID',
      patient: 'Patient',
      tests: 'Tests',
      status: 'Status',
      priority: 'Priority',
      date: 'Date',
      actions: 'Actions',
      close: 'Close',
      save: 'Save',
      cancel: 'Cancel'
    }
  }[language];

  // Load requests from local storage
  useEffect(() => {
    const loadRequests = async () => {
      try {
        const result = await sheetsService.getRequests();
        if (result.success && result.data) {
          // Transform the data to match the Request interface
          const transformedRequests = result.data.map((req: any) => ({
            id: req.id || `REQ${Date.now()}`,
            patientName: `${req.patient?.nom || ''}, ${req.patient?.prenom || ''}`,
            tests: req.analyses?.map((a: any) => a.nom) || [],
            status: req.status || 'created',
            priority: req.urgent ? 'urgent' : 'normal',
            createdAt: req.createdAt || req.timestamp || new Date().toISOString()
          }));
          setRequests(transformedRequests);
        }
      } catch (error) {
        console.error('Error loading requests:', error);
        // Fallback to empty array
        setRequests([]);
      } finally {
        setLoading(false);
      }
    };

    loadRequests();
  }, []);

  // Filter requests based on search term
  const filteredRequests = requests.filter(request =>
    request.patientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    request.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
    request.tests.some(test => test.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const getStatusColor = (status: string) => {
    const colors = {
      created: 'bg-gray-100 text-gray-800',
      collected: 'bg-blue-100 text-blue-800',
      analysis: 'bg-yellow-100 text-yellow-800',
      validated: 'bg-green-100 text-green-800'
    };
    return colors[status as keyof typeof colors] || 'bg-gray-100 text-gray-800';
  };

  const getPriorityColor = (priority: string) => {
    return priority === 'urgent' 
      ? 'bg-red-100 text-red-800' 
      : 'bg-gray-100 text-gray-800';
  };

  const handleView = (request: Request) => {
    setSelectedRequest(request);
    setShowViewModal(true);
  };

  const handleEdit = (request: Request) => {
    setSelectedRequest(request);
    setShowNewModal(true);
  };

  const NewRequestModal = () => (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white dark:bg-gray-800 rounded-lg p-6 w-full max-w-md">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
            {selectedRequest ? 'Modifier Demande' : t.newRequest}
          </h3>
          <button onClick={() => setShowNewModal(false)}>
            <X size={20} className="text-gray-500" />
          </button>
        </div>
        <div className="space-y-4">
          <input
            type="text"
            placeholder="Nom du patient"
            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg dark:bg-gray-700 dark:text-white"
          />
          <select className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg dark:bg-gray-700 dark:text-white">
            <option>Sélectionner tests</option>
            <option>Hémogramme</option>
            <option>Glycémie</option>
          </select>
          <select className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg dark:bg-gray-700 dark:text-white">
            <option>Priorité normale</option>
            <option>Urgent</option>
          </select>
        </div>
        <div className="flex justify-end space-x-3 mt-6">
          <button
            onClick={() => setShowNewModal(false)}
            className="px-4 py-2 text-gray-600 hover:text-gray-800"
          >
            {t.cancel}
          </button>
          <button
            onClick={() => setShowNewModal(false)}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
          >
            {t.save}
          </button>
        </div>
      </div>
    </div>
  );

  const ViewRequestModal = () => (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white dark:bg-gray-800 rounded-lg p-6 w-full max-w-md">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Détails de la demande</h3>
          <button onClick={() => setShowViewModal(false)}>
            <X size={20} className="text-gray-500" />
          </button>
        </div>
        {selectedRequest && (
          <div className="space-y-3">
            <div><strong>ID:</strong> {selectedRequest.id}</div>
            <div><strong>Patient:</strong> {selectedRequest.patientName}</div>
            <div><strong>Tests:</strong> {selectedRequest.tests.join(', ')}</div>
            <div><strong>Statut:</strong> {selectedRequest.status}</div>
            <div><strong>Priorité:</strong> {selectedRequest.priority}</div>
            <div><strong>Date:</strong> {selectedRequest.createdAt}</div>
          </div>
        )}
        <div className="flex justify-end mt-6">
          <button
            onClick={() => setShowViewModal(false)}
            className="px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700"
          >
            {t.close}
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-3xl font-bold text-gray-900 dark:text-white">{t.title}</h2>
        <button 
          onClick={() => setShowNewModal(true)}
          className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 flex items-center"
        >
          <Plus size={20} className="mr-2" />
          {t.newRequest}
        </button>
      </div>

      <div className="mb-6 flex space-x-4">
        <div className="relative flex-1">
          <Search size={20} className="absolute left-3 top-3 text-gray-400" />
          <input
            type="text"
            placeholder={t.search}
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
          />
        </div>
        <button 
          onClick={() => setShowFilter(!showFilter)}
          className="bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300 px-4 py-2 rounded-lg hover:bg-gray-300 dark:hover:bg-gray-600 flex items-center"
        >
          <Filter size={20} className="mr-2" />
          Filter
        </button>
      </div>

      {showFilter && (
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-4 mb-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <select className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg dark:bg-gray-700 dark:text-white">
              <option>Tous les statuts</option>
              <option>Créé</option>
              <option>Collecté</option>
              <option>En analyse</option>
              <option>Validé</option>
            </select>
            <select className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg dark:bg-gray-700 dark:text-white">
              <option>Toutes priorités</option>
              <option>Normal</option>
              <option>Urgent</option>
            </select>
            <input
              type="date"
              className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg dark:bg-gray-700 dark:text-white"
            />
          </div>
        </div>
      )}

      <div className="bg-white dark:bg-gray-800 rounded-lg shadow overflow-hidden">
        <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
          <thead className="bg-gray-50 dark:bg-gray-700">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">{t.id}</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">{t.patient}</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">{t.tests}</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">{t.status}</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">{t.priority}</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">{t.date}</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">{t.actions}</th>
            </tr>
          </thead>
          <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
            {loading ? (
              <tr>
                <td colSpan={7} className="px-6 py-8 text-center">
                  <div className="flex items-center justify-center">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                    <span className="ml-2 text-gray-600 dark:text-gray-400">Chargement...</span>
                  </div>
                </td>
              </tr>
            ) : filteredRequests.length === 0 ? (
              <tr>
                <td colSpan={7} className="px-6 py-8 text-center">
                  <div className="text-gray-500 dark:text-gray-400">
                    {searchTerm ? 'Aucune demande trouvée pour cette recherche.' : 'Aucune demande enregistrée.'}
                  </div>
                </td>
              </tr>
            ) : (
              filteredRequests.map((request) => (
                <tr key={request.id}>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 dark:text-white">{request.id}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">{request.patientName}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">
                    {request.tests.join(', ')}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(request.status)}`}>
                      {request.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getPriorityColor(request.priority)}`}>
                      {request.priority}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">
                    {new Date(request.createdAt).toLocaleDateString()}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                    <button 
                      onClick={() => handleView(request)}
                      className="text-blue-600 hover:text-blue-900 mr-3"
                    >
                      <Eye size={16} />
                    </button>
                    <button 
                      onClick={() => handleEdit(request)}
                      className="text-green-600 hover:text-green-900"
                    >
                      <Edit size={16} />
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {showNewModal && <NewRequestModal />}
      {showViewModal && <ViewRequestModal />}
    </div>
  );
}
 