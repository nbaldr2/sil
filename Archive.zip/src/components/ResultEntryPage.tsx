import  React, { useState } from 'react';
import { Search, Scan, User, Calendar, FileText } from 'lucide-react';
import { useAuth } from '../App';
import ResultEntryForm from './ResultEntryForm';

interface RequestInfo {
  id: string;
  patientName: string;
  patientId: string;
  requestDate: string;
  doctorName: string;
  status: string;
}

export default function ResultEntryPage() {
  const { language } = useAuth();
  const [requestId, setRequestId] = useState('');
  const [requestInfo, setRequestInfo] = useState<RequestInfo | null>(null);
  const [loading, setLoading] = useState(false);

  const t = {
    fr: {
      title: 'Saisie des Résultats',
      searchPlaceholder: 'ID demande ou code-barres',
      search: 'Rechercher',
      patient: 'Patient',
      request: 'Demande',
      doctor: 'Médecin',
      date: 'Date',
      status: 'Statut',
      notFound: 'Demande non trouvée'
    },
    en: {
      title: 'Result Entry',
      searchPlaceholder: 'Request ID or barcode',
      search: 'Search',
      patient: 'Patient',
      request: 'Request',
      doctor: 'Doctor',
      date: 'Date',
      status: 'Status',
      notFound: 'Request not found'
    }
  }[language];

  const fetchRequestInfo = async () => {
    if (!requestId.trim()) return;
    
    setLoading(true);
    // Simulate API call
    setTimeout(() => {
      setRequestInfo({
        id: requestId,
        patientName: 'Kabbaj, Ahmed',
        patientId: 'PAT001',
        requestDate: '2024-01-15',
        doctorName: 'Dr. Bensaïd, Youssef',
        status: 'En cours'
      });
      setLoading(false);
    }, 500);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      fetchRequestInfo();
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white">{t.title}</h1>
      </div>

      {/* Search Section */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
        <div className="flex items-center space-x-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
            <input
              type="text"
              value={requestId}
              onChange={(e) => setRequestId(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder={t.searchPlaceholder}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
            />
          </div>
          <button
            onClick={fetchRequestInfo}
            disabled={loading}
            className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 flex items-center space-x-2"
          >
            <Scan size={20} />
            <span>{t.search}</span>
          </button>
        </div>
      </div>

      {/* Request Info Section */}
      {requestInfo && (
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="flex items-center space-x-2">
              <User className="text-blue-600" size={20} />
              <div>
                <p className="text-sm text-gray-500 dark:text-gray-400">{t.patient}</p>
                <p className="font-medium text-gray-900 dark:text-white">{requestInfo.patientName}</p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <FileText className="text-green-600" size={20} />
              <div>
                <p className="text-sm text-gray-500 dark:text-gray-400">{t.request}</p>
                <p className="font-medium text-gray-900 dark:text-white">{requestInfo.id}</p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <User className="text-purple-600" size={20} />
              <div>
                <p className="text-sm text-gray-500 dark:text-gray-400">{t.doctor}</p>
                <p className="font-medium text-gray-900 dark:text-white">{requestInfo.doctorName}</p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <Calendar className="text-orange-600" size={20} />
              <div>
                <p className="text-sm text-gray-500 dark:text-gray-400">{t.date}</p>
                <p className="font-medium text-gray-900 dark:text-white">{requestInfo.requestDate}</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Result Entry Form */}
      {requestInfo && <ResultEntryForm requestInfo={requestInfo} />}
    </div>
  );
}
 