import  React from 'react';
import { Sun, Moon, Globe, LogOut } from 'lucide-react';
import { useAuth } from '../App';

export default function Header() {
  const { user, logout, theme, toggleTheme, language, setLanguage } = useAuth();

  return (
    <header className="bg-white dark:bg-gray-800 shadow-sm border-b border-gray-200 dark:border-gray-700 h-16 flex items-center justify-between px-6">
      <div className="flex items-center">
        <h1 className="text-xl font-semibold text-gray-900 dark:text-white">
          SIL Laboratory System
        </h1>
      </div>
      
      <div className="flex items-center space-x-4">
        <button
          onClick={toggleTheme}
          className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
          aria-label={theme === 'light' ? 'Switch to dark mode' : 'Switch to light mode'}
        >
          {theme === 'light' ? (
            <Moon size={20} className="text-gray-600 dark:text-gray-300" />
          ) : (
            <Sun size={20} className="text-gray-600 dark:text-gray-300" />
          )}
        </button>
        
        <div className="flex items-center space-x-2">
          <Globe size={20} className="text-gray-600 dark:text-gray-300" />
          <select
            value={language}
            onChange={(e) => setLanguage(e.target.value as 'fr' | 'en')}
            className="bg-transparent text-sm text-gray-700 dark:text-gray-300 focus:outline-none"
          >
            <option value="fr">Français</option>
            <option value="en">English</option>
          </select>
        </div>
        
        <div className="flex items-center space-x-3">
          <span className="text-sm text-gray-700 dark:text-gray-300">
            {user?.name}
          </span>
          <button
            onClick={logout}
            className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
          >
            <LogOut size={20} className="text-gray-600 dark:text-gray-300" />
          </button>
        </div>
      </div>
    </header>
  );
}
 