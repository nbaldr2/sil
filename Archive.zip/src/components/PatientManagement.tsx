import  React, { useState } from 'react';
import { Plus, Search, Edit, Eye, X } from 'lucide-react';
import { useAuth } from '../App';

interface Patient {
  id: string;
  name: string;
  birthDate: string;
  socialSecurity: string;
  phone: string;
  email: string;
  lastVisit: string;
}

export default function PatientManagement() {
  const { language } = useAuth();
  const [searchTerm, setSearchTerm] = useState('');
  const [showNewModal, setShowNewModal] = useState(false);
  const [showViewModal, setShowViewModal] = useState(false);
  const [selectedPatient, setSelectedPatient] = useState<Patient | null>(null);

  const t = {
    fr: {
      title: 'Gestion des Patients',
      newPatient: 'Nouveau Patient',
      search: 'Rechercher un patient...',
      name: 'Nom',
      birthDate: 'Date de Naissance',
      socialSecurity: 'Sécurité Sociale',
      phone: 'Téléphone',
      email: 'Email',
      lastVisit: 'Dernière Visite',
      actions: 'Actions',
      close: 'Fermer',
      save: 'Enregistrer',
      cancel: 'Annuler'
    },
    en: {
      title: 'Patient Management',
      newPatient: 'New Patient',
      search: 'Search patient...',
      name: 'Name',
      birthDate: 'Birth Date',
      socialSecurity: 'Social Security',
      phone: 'Phone',
      email: 'Email',
      lastVisit: 'Last Visit',
      actions: 'Actions',
      close: 'Close',
      save: 'Save',
      cancel: 'Cancel'
    }
  }[language];

  const [patients] = useState<Patient[]>([
    {
      id: 'PAT001',
      name: 'Dupont, Marie',
      birthDate: '1985-03-12',
      socialSecurity: '2 85 03 12 456 123',
      phone: '01.42.34.56.78',
      email: 'marie.dupont@email.fr',
      lastVisit: '2024-01-15'
    },
    {
      id: 'PAT002',
      name: 'Martin, Pierre',
      birthDate: '1978-07-25',
      socialSecurity: '1 78 07 25 789 456',
      phone: '01.42.34.56.79',
      email: 'pierre.martin@email.fr',
      lastVisit: '2024-01-14'
    }
  ]);

  const handleView = (patient: Patient) => {
    setSelectedPatient(patient);
    setShowViewModal(true);
  };

  const handleEdit = (patient: Patient) => {
    setSelectedPatient(patient);
    setShowNewModal(true);
  };

  const NewPatientModal = () => (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white dark:bg-gray-800 rounded-lg p-6 w-full max-w-md">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
            {selectedPatient ? 'Modifier Patient' : t.newPatient}
          </h3>
          <button onClick={() => setShowNewModal(false)}>
            <X size={20} className="text-gray-500" />
          </button>
        </div>
        <div className="space-y-4">
          <input
            type="text"
            placeholder="Nom complet"
            defaultValue={selectedPatient?.name || ''}
            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg dark:bg-gray-700 dark:text-white"
          />
          <input
            type="date"
            defaultValue={selectedPatient?.birthDate || ''}
            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg dark:bg-gray-700 dark:text-white"
          />
          <input
            type="text"
            placeholder="Sécurité Sociale"
            defaultValue={selectedPatient?.socialSecurity || ''}
            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg dark:gray-700 dark:text-white"
          />
          <input
            type="tel"
            placeholder="Téléphone"
            defaultValue={selectedPatient?.phone || ''}
            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg dark:bg-gray-700 dark:text-white"
          />
          <input
            type="email"
            placeholder="Email"
            defaultValue={selectedPatient?.email || ''}
            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg dark:bg-gray-700 dark:text-white"
          />
        </div>
        <div className="flex justify-end space-x-3 mt-6">
          <button
            onClick={() => setShowNewModal(false)}
            className="px-4 py-2 text-gray-600 hover:text-gray-800"
          >
            {t.cancel}
          </button>
          <button
            onClick={() => setShowNewModal(false)}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
          >
            {t.save}
          </button>
        </div>
      </div>
    </div>
  );

  const ViewPatientModal = () => (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white dark:bg-gray-800 rounded-lg p-6 w-full max-w-md">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Détails du patient</h3>
          <button onClick={() => setShowViewModal(false)}>
            <X size={20} className="text-gray-500" />
          </button>
        </div>
        {selectedPatient && (
          <div className="space-y-3">
            <div><strong>ID:</strong> {selectedPatient.id}</div>
            <div><strong>Nom:</strong> {selectedPatient.name}</div>
            <div><strong>Date de naissance:</strong> {selectedPatient.birthDate}</div>
            <div><strong>Sécurité Sociale:</strong> {selectedPatient.socialSecurity}</div>
            <div><strong>Téléphone:</strong> {selectedPatient.phone}</div>
            <div><strong>Email:</strong> {selectedPatient.email}</div>
            <div><strong>Dernière visite:</strong> {selectedPatient.lastVisit}</div>
          </div>
        )}
        <div className="flex justify-end mt-6">
          <button
            onClick={() => setShowViewModal(false)}
            className="px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700"
          >
            {t.close}
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-3xl font-bold text-gray-900 dark:text-white">{t.title}</h2>
        <button 
          onClick={() => setShowNewModal(true)}
          className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 flex items-center"
        >
          <Plus size={20} className="mr-2" />
          {t.newPatient}
        </button>
      </div>

      <div className="mb-6">
        <div className="relative">
          <Search size={20} className="absolute left-3 top-3 text-gray-400" />
          <input
            type="text"
            placeholder={t.search}
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
          />
        </div>
      </div>

      <div className="bg-white dark:bg-gray-800 rounded-lg shadow overflow-hidden">
        <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
          <thead className="bg-gray-50 dark:bg-gray-700">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">{t.name}</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">{t.birthDate}</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">{t.socialSecurity}</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">{t.phone}</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">{t.lastVisit}</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">{t.actions}</th>
            </tr>
          </thead>
          <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
            {patients.map((patient) => (
              <tr key={patient.id}>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 dark:text-white">{patient.name}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">{patient.birthDate}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">{patient.socialSecurity}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">{patient.phone}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">{patient.lastVisit}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                  <button 
                    onClick={() => handleView(patient)}
                    className="text-blue-600 hover:text-blue-900 mr-3"
                  >
                    <Eye size={16} />
                  </button>
                  <button 
                    onClick={() => handleEdit(patient)}
                    className="text-green-600 hover:text-green-900"
                  >
                    <Edit size={16} />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {showNewModal && <NewPatientModal />}
      {showViewModal && <ViewPatientModal />}
    </div>
  );
}
 