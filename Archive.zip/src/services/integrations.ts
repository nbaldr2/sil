//  External integrations through proxy server

const PROXY_URL = 'https://hooks.jdoodle.net';

// Local storage fallback for development
const LOCAL_STORAGE_KEY = 'sil_lab_requests';
const PRICES_STORAGE_KEY = 'sil_lab_prices';

// Utility function to view saved requests in console
export const debugRequests = () => {
  try {
    const requests = JSON.parse(localStorage.getItem(LOCAL_STORAGE_KEY) || '[]');
    console.log('📋 Saved Requests:', requests);
    return requests;
  } catch (error) {
    console.error('Error reading requests:', error);
    return [];
  }
};

// Pricing service
export const pricingService = {
  getPrices: () => {
    try {
      const prices = JSON.parse(localStorage.getItem(PRICES_STORAGE_KEY) || '[]');
      return prices;
    } catch (error) {
      console.error('Error reading prices:', error);
      return [];
    }
  },

  savePrices: (prices: any[]) => {
    try {
      localStorage.setItem(PRICES_STORAGE_KEY, JSON.stringify(prices));
      return true;
    } catch (error) {
      console.error('Error saving prices:', error);
      return false;
    }
  },

  calculateRequestTotal: (selectedAnalyses: any[], discount: number = 0, advancePayment: number = 0) => {
    const prices = pricingService.getPrices();
    let subtotal = 0;
    let tvaTotal = 0;

    selectedAnalyses.forEach(analysis => {
      const priceInfo = prices.find((p: any) => p.code === analysis.code);
      if (priceInfo) {
        const price = priceInfo.price;
        const tva = priceInfo.tva;
        const tvaAmount = price * (tva / 100);
        
        subtotal += price;
        tvaTotal += tvaAmount;
      }
    });

    const totalBeforeDiscount = subtotal + tvaTotal;
    const discountAmount = totalBeforeDiscount * (discount / 100);
    const totalAfterDiscount = totalBeforeDiscount - discountAmount;
    const amountDue = totalAfterDiscount - advancePayment;

    return {
      subtotal: subtotal,
      tvaTotal: tvaTotal,
      totalBeforeDiscount: totalBeforeDiscount,
      discount: discount,
      discountAmount: discountAmount,
      totalAfterDiscount: totalAfterDiscount,
      advancePayment: advancePayment,
      amountDue: amountDue
    };
  }
};

// Google Sheets integration for data storage
export const sheetsService = {
  saveRequest: async (requestData: any) => {
    try {
      // First try external service
      const response = await fetch(`${PROXY_URL}?url=https://script.google.com/macros/s/YOUR_SCRIPT_ID/exec`, {
        method: 'POST',
        body: JSON.stringify({
          action: 'saveRequest',
          data: requestData
        })
      });
      
      if (response.ok) {
        return response.json();
      } else {
        throw new Error('External service unavailable');
      }
    } catch (error) {
      console.warn('External service failed, using local storage fallback:', error);
      
      // Fallback to local storage
      try {
        const existingRequests = JSON.parse(localStorage.getItem(LOCAL_STORAGE_KEY) || '[]');
        const newRequest = {
          id: `REQ${Date.now()}`,
          ...requestData,
          createdAt: new Date().toISOString(),
          status: 'created'
        };
        
        existingRequests.push(newRequest);
        localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(existingRequests));
        
        console.log('✅ Request saved to local storage:', newRequest);
        console.log('💡 Use debugRequests() in console to view all saved requests');
        return { success: true, data: newRequest };
      } catch (localError) {
        console.error('❌ Local storage fallback failed:', localError);
        throw new Error('Failed to save request both externally and locally');
      }
    }
  },

  getRequests: async () => {
    try {
      // Try external service first
      const response = await fetch(`${PROXY_URL}?url=https://script.google.com/macros/s/YOUR_SCRIPT_ID/exec`, {
        method: 'POST',
        body: JSON.stringify({
          action: 'getRequests'
        })
      });
      
      if (response.ok) {
        return response.json();
      } else {
        throw new Error('External service unavailable');
      }
    } catch (error) {
      console.warn('External service failed, using local storage fallback:', error);
      
      // Fallback to local storage
      try {
        const requests = JSON.parse(localStorage.getItem(LOCAL_STORAGE_KEY) || '[]');
        return { success: true, data: requests };
      } catch (localError) {
        console.error('Local storage fallback failed:', localError);
        return { success: false, data: [] };
      }
    }
  },

  getAnalytics: async () => {
    try {
      const response = await fetch(`${PROXY_URL}?url=https://script.google.com/macros/s/YOUR_SCRIPT_ID/exec`, {
        method: 'POST',
        body: JSON.stringify({
          action: 'getAnalytics'
        })
      });
      return response.json();
    } catch (error) {
      console.error('Analytics fetch error:', error);
      throw error;
    }
  }
};

// Print service for labels and receipts
export const printService = {
  printLabels: (requestData: any) => {
    try {
      // Generate barcode (using a simple implementation)
      const barcode = `*${requestData.id}*`;
      
      // Create print content
      const printContent = `
        <div style="font-family: Arial, sans-serif; width: 300px; padding: 10px; border: 1px solid #000;">
          <div style="text-align: center; margin-bottom: 10px;">
            <h3 style="margin: 0;">SIL LABORATORY</h3>
            <p style="margin: 5px 0;">Sample Label</p>
          </div>
          
          <div style="margin-bottom: 10px;">
            <strong>Patient:</strong> ${requestData.patient.prenom} ${requestData.patient.nom}<br>
            <strong>ID:</strong> ${requestData.id}<br>
            <strong>Date:</strong> ${new Date().toLocaleDateString()}<br>
            <strong>Time:</strong> ${new Date().toLocaleTimeString()}
          </div>
          
          <div style="margin-bottom: 10px;">
            <strong>Analyses:</strong><br>
            ${requestData.analyses.map((a: any) => `• ${a.nom}`).join('<br>')}
          </div>
          
          <div style="text-align: center; margin-top: 15px;">
            <div style="font-family: monospace; font-size: 18px; letter-spacing: 2px;">
              ${barcode}
            </div>
            <div style="font-size: 12px; margin-top: 5px;">
              ${requestData.id}
            </div>
          </div>
          
          <div style="margin-top: 10px; font-size: 12px; text-align: center;">
            <strong>Urgent:</strong> ${requestData.urgent ? 'OUI' : 'NON'}
          </div>
        </div>
      `;
      
      // Open print window
      const printWindow = window.open('', '_blank');
      if (printWindow) {
        printWindow.document.write(`
          <html>
            <head>
              <title>Print Labels</title>
              <style>
                body { margin: 0; padding: 10px; }
                @media print {
                  body { margin: 0; }
                }
              </style>
            </head>
            <body>
              ${printContent}
              <script>
                window.onload = function() {
                  window.print();
                  window.close();
                };
              </script>
            </body>
          </html>
        `);
        printWindow.document.close();
      }
      
      console.log('🖨️ Labels printed for request:', requestData.id);
      return true;
    } catch (error) {
      console.error('Print error:', error);
      return false;
    }
  },

  printReceipt: (requestData: any, pricingData: any) => {
    try {
      const printContent = `
        <div style="font-family: Arial, sans-serif; width: 400px; padding: 20px;">
          <div style="text-align: center; margin-bottom: 20px;">
            <h2 style="margin: 0;">SIL LABORATORY</h2>
            <p style="margin: 5px 0;">123 Rue de la Santé, 75014 Paris</p>
            <p style="margin: 5px 0;">Tel: 01.42.34.56.78</p>
          </div>
          
          <div style="border-bottom: 1px solid #ccc; padding-bottom: 10px; margin-bottom: 15px;">
            <strong>Reçu de Paiement</strong><br>
            <strong>Date:</strong> ${new Date().toLocaleDateString()}<br>
            <strong>Heure:</strong> ${new Date().toLocaleTimeString()}<br>
            <strong>N° Demande:</strong> ${requestData.id}
          </div>
          
          <div style="margin-bottom: 15px;">
            <strong>Patient:</strong> ${requestData.patient.prenom} ${requestData.patient.nom}<br>
            <strong>CNSS:</strong> ${requestData.patient.numeroCNSS}
          </div>
          
          <table style="width: 100%; border-collapse: collapse; margin-bottom: 15px;">
            <thead>
              <tr style="border-bottom: 1px solid #ccc;">
                <th style="text-align: left; padding: 5px;">Analyse</th>
                <th style="text-align: right; padding: 5px;">Prix HT</th>
                <th style="text-align: right; padding: 5px;">TVA</th>
                <th style="text-align: right; padding: 5px;">Total</th>
              </tr>
            </thead>
            <tbody>
              ${requestData.analyses.map((analysis: any) => {
                const priceInfo = pricingData.prices.find((p: any) => p.code === analysis.code);
                const price = priceInfo ? priceInfo.price : 0;
                const tva = priceInfo ? priceInfo.tva : 20;
                const tvaAmount = price * (tva / 100);
                const total = price + tvaAmount;
                
                return `
                  <tr>
                    <td style="padding: 5px;">${analysis.nom}</td>
                    <td style="text-align: right; padding: 5px;">${price.toFixed(2)} dh</td>
                    <td style="text-align: right; padding: 5px;">${tvaAmount.toFixed(2)} dh</td>
                    <td style="text-align: right; padding: 5px;">${total.toFixed(2)} dh</td>
                  </tr>
                `;
              }).join('')}
            </tbody>
          </table>
          
          <div style="border-top: 1px solid #ccc; padding-top: 10px;">
            <div style="display: flex; justify-content: space-between; margin-bottom: 5px;">
              <span>Sous-total HT:</span>
              <span>${pricingData.subtotal.toFixed(2)} dh</span>
            </div>
            <div style="display: flex; justify-content: space-between; margin-bottom: 5px;">
              <span>TVA:</span>
              <span>${pricingData.tvaTotal.toFixed(2)} dh</span>
            </div>
            <div style="display: flex; justify-content: space-between; margin-bottom: 5px;">
              <span>Total TTC:</span>
              <span>${pricingData.totalBeforeDiscount.toFixed(2)} dh</span>
            </div>
            ${pricingData.discount > 0 ? `
              <div style="display: flex; justify-content: space-between; margin-bottom: 5px;">
                <span>Remise (${pricingData.discount}%):</span>
                <span>-${pricingData.discountAmount.toFixed(2)} dh</span>
              </div>
            ` : ''}
            ${pricingData.advancePayment > 0 ? `
              <div style="display: flex; justify-content: space-between; margin-bottom: 5px;">
                <span>Acompte:</span>
                <span>-${pricingData.advancePayment.toFixed(2)} dh</span>
              </div>
            ` : ''}
            <div style="display: flex; justify-content: space-between; font-weight: bold; border-top: 1px solid #000; padding-top: 5px;">
              <span>Montant dû:</span>
              <span>${pricingData.amountDue.toFixed(2)} dh</span>
            </div>
          </div>
          
          <div style="margin-top: 20px; text-align: center; font-size: 12px;">
            <p>Merci de votre confiance</p>
            <p>Résultats disponibles sous 24-48h</p>
          </div>
        </div>
      `;
      
      // Open print window
      const printWindow = window.open('', '_blank');
      if (printWindow) {
        printWindow.document.write(`
          <html>
            <head>
              <title>Print Receipt</title>
              <style>
                body { margin: 0; padding: 10px; }
                @media print {
                  body { margin: 0; }
                }
              </style>
            </head>
            <body>
              ${printContent}
              <script>
                window.onload = function() {
                  window.print();
                  window.close();
                };
              </script>
            </body>
          </html>
        `);
        printWindow.document.close();
      }
      
      console.log('🧾 Receipt printed for request:', requestData.id);
      return true;
    } catch (error) {
      console.error('Print error:', error);
      return false;
    }
  }
};

// SendGrid integration for email notifications
export const emailService = {
  sendResultNotification: async (patientEmail: string, requestId: string) => {
    try {
      const response = await fetch(`${PROXY_URL}?url=https://api.sendgrid.com/v3/mail/send`, {
        method: 'POST',
        body: JSON.stringify({
          personalizations: [{
            to: [{ email: patientEmail }],
            subject: `Résultats d'analyses - Demande ${requestId}`
          }],
          from: { email: 'noreply@laboratoire.fr' },
          content: [{
            type: 'text/html',
            value: `Vos résultats d'analyses pour la demande ${requestId} sont disponibles.`
          }]
        })
      });
      return response.json();
    } catch (error) {
      console.error('Email service error:', error);
      throw error;
    }
  }
};

// Twilio integration for SMS alerts
export const smsService = {
  sendUrgentAlert: async (phoneNumber: string, message: string) => {
    try {
      const response = await fetch(`${PROXY_URL}?url=https://api.twilio.com/2010-04-01/Accounts/YOUR_ACCOUNT_SID/Messages.json`, {
        method: 'POST',
        body: JSON.stringify({
          To: phoneNumber,
          From: '+33123456789',
          Body: message
        })
      });
      return response.json();
    } catch (error) {
      console.error('SMS service error:', error);
      throw error;
    }
  }
};
 