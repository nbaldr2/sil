const express = require('express');
const { body, validationResult } = require('express-validator');
const { PrismaClient } = require('@prisma/client');

const router = express.Router();
const prisma = new PrismaClient();

// Validation middleware
const patientValidation = [
  body('nom').isLength({ min: 2 }).trim(),
  body('prenom').isLength({ min: 2 }).trim(),
  body('dateNaissance').isLength({ min: 1 }),
  body('numeroCNSS').isLength({ min: 1 }),
  body('sexe').isIn(['M', 'F'])
];

// Get all patients
router.get('/', async (req, res) => {
  try {
    const { search, page = 1, limit = 10 } = req.query;
    
    const skip = (parseInt(page) - 1) * parseInt(limit);
    
    let whereClause = {};
    
    if (search) {
      whereClause = {
        OR: [
          { nom: { contains: search, mode: 'insensitive' } },
          { prenom: { contains: search, mode: 'insensitive' } },
          { numeroCNSS: { contains: search, mode: 'insensitive' } }
        ]
      };
    }

    const [patients, total] = await Promise.all([
      prisma.patient.findMany({
        where: whereClause,
        skip,
        take: parseInt(limit),
        orderBy: { createdAt: 'desc' },
        include: {
          _count: {
            select: { requests: true }
          }
        }
      }),
      prisma.patient.count({ where: whereClause })
    ]);

    res.json({
      patients,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total,
        pages: Math.ceil(total / parseInt(limit))
      }
    });

  } catch (error) {
    console.error('Get patients error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get patient by ID
router.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;

    const patient = await prisma.patient.findUnique({
      where: { id },
      include: {
        requests: {
          include: {
            doctor: true,
            requestAnalyses: {
              include: {
                analysis: true
              }
            }
          },
          orderBy: { createdAt: 'desc' }
        }
      }
    });

    if (!patient) {
      return res.status(404).json({ error: 'Patient not found' });
    }

    res.json({ patient });

  } catch (error) {
    console.error('Get patient error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Create patient
router.post('/', patientValidation, async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { nom, prenom, dateNaissance, numeroCNSS, sexe, adresse, telephone, email } = req.body;

    // Check if patient with same CNSS already exists
    const existingPatient = await prisma.patient.findUnique({
      where: { numeroCNSS }
    });

    if (existingPatient) {
      return res.status(400).json({ error: 'Patient with this CNSS number already exists' });
    }

    const patient = await prisma.patient.create({
      data: {
        nom,
        prenom,
        dateNaissance,
        numeroCNSS,
        sexe,
        adresse,
        telephone,
        email
      }
    });

    res.status(201).json({ patient });

  } catch (error) {
    console.error('Create patient error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Update patient
router.put('/:id', patientValidation, async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { id } = req.params;
    const { nom, prenom, dateNaissance, numeroCNSS, sexe, adresse, telephone, email } = req.body;

    // Check if patient exists
    const existingPatient = await prisma.patient.findUnique({
      where: { id }
    });

    if (!existingPatient) {
      return res.status(404).json({ error: 'Patient not found' });
    }

    // Check if CNSS number is being changed and if it already exists
    if (numeroCNSS !== existingPatient.numeroCNSS) {
      const patientWithSameCNSS = await prisma.patient.findUnique({
        where: { numeroCNSS }
      });

      if (patientWithSameCNSS) {
        return res.status(400).json({ error: 'Patient with this CNSS number already exists' });
      }
    }

    const patient = await prisma.patient.update({
      where: { id },
      data: {
        nom,
        prenom,
        dateNaissance,
        numeroCNSS,
        sexe,
        adresse,
        telephone,
        email
      }
    });

    res.json({ patient });

  } catch (error) {
    console.error('Update patient error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Delete patient
router.delete('/:id', async (req, res) => {
  try {
    const { id } = req.params;

    // Check if patient exists
    const patient = await prisma.patient.findUnique({
      where: { id },
      include: {
        _count: {
          select: { requests: true }
        }
      }
    });

    if (!patient) {
      return res.status(404).json({ error: 'Patient not found' });
    }

    // Check if patient has requests
    if (patient._count.requests > 0) {
      return res.status(400).json({ 
        error: 'Cannot delete patient with existing requests',
        requestCount: patient._count.requests
      });
    }

    await prisma.patient.delete({
      where: { id }
    });

    res.json({ message: 'Patient deleted successfully' });

  } catch (error) {
    console.error('Delete patient error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get patient statistics
router.get('/stats/overview', async (req, res) => {
  try {
    const [totalPatients, newPatientsThisMonth, patientsWithRequests] = await Promise.all([
      prisma.patient.count(),
      prisma.patient.count({
        where: {
          createdAt: {
            gte: new Date(new Date().getFullYear(), new Date().getMonth(), 1)
          }
        }
      }),
      prisma.patient.count({
        where: {
          requests: {
            some: {}
          }
        }
      })
    ]);

    res.json({
      totalPatients,
      newPatientsThisMonth,
      patientsWithRequests,
      patientsWithoutRequests: totalPatients - patientsWithRequests
    });

  } catch (error) {
    console.error('Get patient stats error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

module.exports = router; 